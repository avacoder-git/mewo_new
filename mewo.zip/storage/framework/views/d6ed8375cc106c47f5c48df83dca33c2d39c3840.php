<!-- Nav Item - Charts -->
<li class="nav-item <?php if(session()->has(['activeness']) && session('activeness')== 'video_comments'): ?> active   <?php endif; ?>">
    <a class="nav-link " href="<?php echo e(route('video_comments', ['size'=>25])); ?>">
        <i class="fas fa-fw fa-table"></i>
        <span>Видео отзыв</span></a>
</li>
<?php /**PATH /home/vagrant/code/mewo/resources/views/components/video-comment-links.blade.php ENDPATH**/ ?>