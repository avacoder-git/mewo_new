<!-- Nav Item - Charts -->
<li class="nav-item <?php if(session()->has(['activeness']) && session('activeness')== 'coworkers'): ?> active   <?php endif; ?>">
    <a class="nav-link " href="<?php echo e(route('coworkers', ['size'=>25])); ?>">
        <i class="fas fa-fw fa-table"></i>
        <span>Рекомендации</span></a>
</li>
<?php /**PATH C:\laravel\mewo\resources\views/components/coworkers-links.blade.php ENDPATH**/ ?>