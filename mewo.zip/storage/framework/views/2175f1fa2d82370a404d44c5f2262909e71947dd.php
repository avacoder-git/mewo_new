<!-- Nav Item - Charts -->
<li class="nav-item <?php if(session()->has(['activeness']) && session('activeness')== 'reviews'): ?> active   <?php endif; ?>">
    <a class="nav-link " href="<?php echo e(route('reviews', ['size'=>25])); ?>">
        <i class="fas fa-fw fa-table"></i>
        <span>Отзыв</span></a>
</li>
<?php /**PATH C:\laravel\mewo\resources\views/components/reviews-links.blade.php ENDPATH**/ ?>