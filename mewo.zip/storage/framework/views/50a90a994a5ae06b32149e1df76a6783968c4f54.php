 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin-master','data' => []]); ?>
<?php $component->withName('admin-master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startSection('content'); ?>


        <h1>Редактировать отзыв № <?php echo e($review->id); ?></h1>


        <form action="<?php echo e(route('reviews.update', $review)); ?>" enctype="multipart/form-data" method="post">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Редактировать отзыв № <?php echo e($review->id); ?></h6>
                        </div>
                        <div class="card-body">
                            <div class="">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-default">Автор</span>
                                    </div>
                                    <input type="text" name="author" value="<?php echo e($review->author); ?>" required class="form-control" aria-label="Sizing example input">

                                </div>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="email">Текст</span>
                                    </div>
                                    <textarea name="text" id="text" class="form-control" style="resize: none" cols="30" rows="5"><?php echo e($review->text); ?></textarea>
                                </div>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-default">Автор уз</span>
                                    </div>
                                    <input type="text" name="author_uz" value="<?php echo e($review->author_uz); ?>" required class="form-control" aria-label="Sizing example input">
                                </div>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="email">Текст уз</span>
                                    </div>
                                    <textarea name="text_uz" id="text" class="form-control" style="resize: none" cols="30" rows="5"><?php echo e($review->text_uz); ?></textarea>
                                </div>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="password">Оценка</span>
                                    </div>
                                    <input type="number" value="<?php echo e($review->star); ?>" class="form-control" required  name="star" aria-label="Sizing example input">
                                </div>
                                <img src="<?php echo e($review->image); ?>" id="replace_img" alt="">

                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="password_confirmation">Изображение</span>
                                    </div>
                                    <input type="file" class="form-control"  id="image" name="image" aria-label="Sizing example input" >
                                </div>

                                <button type="submit" class="btn btn-primary btn-lg">Применить</button>


                            </div>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger mt-4">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </form>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>

        <link rel="stylesheet" href="<?php echo e(asset('css/cropper.min.css')); ?>">

        <script>

            var image = $('#image');
            input = image;
            var replace = $('#replace_img');
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        replace.attr('src', e.target.result);
                    }
                    reader.readAsDataURL(input.files[0]); // convert to base64 string
                }
            }

            $(input).change(function() {
                readURL(this);
                // alert("heasdfasd");
                $('#replace_img').Cropper();

            });


        </script>
    <?php $__env->stopSection(); ?>


 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /home/vagrant/code/mewo/resources/views/admin/reviews/edit.blade.php ENDPATH**/ ?>