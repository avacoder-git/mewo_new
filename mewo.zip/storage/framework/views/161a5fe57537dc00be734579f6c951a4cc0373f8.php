<!-- Nav Item - Charts -->
<li class="nav-item <?php if(session()->has(['activeness']) && session('activeness')== 'properties'): ?> active   <?php endif; ?>">
    <a class="nav-link " href="<?php echo e(route('properties', ['size'=>25])); ?>">
        <i class="fas fa-fw fa-table"></i>
        <span>Состав</span></a>
</li>
<?php /**PATH C:\laravel\mewo\resources\views/components/property-links.blade.php ENDPATH**/ ?>