<!-- Nav Item - Charts -->
<li class="nav-item <?php if(session()->has(['activeness']) && session('activeness')== 'certificates'): ?> active   <?php endif; ?>">
    <a class="nav-link " href="<?php echo e(route('certificates', ['size'=>25])); ?>">
        <i class="fas fa-fw fa-table"></i>
        <span>Сертификаты</span></a>
</li>
<?php /**PATH /home/vagrant/code/mewo/resources/views/components/certificates-links.blade.php ENDPATH**/ ?>