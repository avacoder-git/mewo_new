<!-- Nav Item - Charts -->
<li class="nav-item <?php if(session()->has(['activeness']) && session('activeness')== 'users'): ?> active   <?php endif; ?>">
    <a class="nav-link " href="<?php echo e(route('users')); ?>">
        <i class="fas fa-fw fa-table"></i>
        <span>Пользователи</span></a>
</li>
<?php /**PATH /home/vagrant/code/mewo/resources/views/components/sidebar-users.blade.php ENDPATH**/ ?>