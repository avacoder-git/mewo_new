 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin-master','data' => []]); ?>
<?php $component->withName('admin-master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startSection('content'); ?>
        <div class="container-fluid">

            <?php if(session()->has('delete_user')): ?>
                <div class="row">
                    <div class="alert alert-danger alert-dismissible fade show col-lg-6" role="alert">
                        <?php echo e(session('deleted')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            <?php elseif(session()->has('updated_user')): ?>
                <div class="row">
                    <div class="alert alert-warning alert-dismissible fade show col-lg-6" role="alert">
                        <?php echo e(session('updated_user')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            <?php elseif(session()->has('created_user')): ?>
                <div class="row">
                    <div class="alert alert-success alert-dismissible fade show col-lg-6" role="alert">
                        <?php echo e(session('create_user')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            <?php endif; ?>

        <!-- Page Heading -->
            <h1 class="h3 mb-2 text-gray-800">Пользователи</h1>
            <!-- DataTales Example -->


            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <div class="row">
                        <div class="col-6">
                            <h6 class="m-0 font-weight-bold text-primary">Пользователи</h6>
                        </div>
                            <div class="ml-auto">
                            <?php if(auth()->user()->userHasRole('administrator')||auth()->user()->userHasRole('owner')): ?>
                                <a class="btn btn-lg btn-primary btn-icon-split" href="<?php echo e(route('users.create')); ?>">
                                <span class="icon text-white-50">
                                            <i class="fas fa-plus"></i>
                                        </span>
                                    <span class="text">Новый</span>
                                </a>
                            <?php endif; ?>
                            </div>
                    </div>

                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Имя</th>
                                <th>Эл. адрес</th>
                                <th>Активность</th>
                                <th>Роль</th>
                                <th>Создано в</th>
                                <?php if(auth()->user()->userHasRole('administrator')||auth()->user()->userHasRole('owner')): ?>
                                    <th>Удалить</th>
                                    <?php endif; ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->role->slug=='owner') continue; ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('users.edit', $user->id)); ?>">
                                            <?php echo e($user->name); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <?php if($user->is_active): ?>
                                            <div class="badge badge-success">Active</div>
                                        <?php else: ?>
                                            <div class="badge badge-danger">inactive</div>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($user->role->name); ?>

                                    </td>
                                    <td><?php echo e($user->created_at->format('d.m.Y')); ?></td>
                                    <td>
                                        <?php if(auth()->user()->userHasRole('administrator')||auth()->user()->userHasRole('owner')): ?>
                                            <form action="<?php echo e(route('users.destroy', $user)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <input type="hidden" value="<?php echo e($user->id); ?>">
                                                <button class="btn btn-danger" >
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                    </td>
                                </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
            <?php echo e($users->links()); ?>


        </div>
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('scripts'); ?>
    <?php $__env->stopSection(); ?>



 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /home/vagrant/code/mewo/resources/views/admin/users/index.blade.php ENDPATH**/ ?>