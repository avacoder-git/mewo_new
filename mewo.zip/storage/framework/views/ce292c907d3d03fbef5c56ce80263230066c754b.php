 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin-master','data' => []]); ?>
<?php $component->withName('admin-master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startSection('content'); ?>

            <h1 class="h3 mb-2 text-gray-800">Заявки</h1>
            <!-- DataTales Example -->


            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <div class="row">
                        <div class="col-12">
                            <h6 class="m-0 font-weight-bold text-primary">Заявки</h6>
                        </div>
                        <div class="ml-auto mr-4">
                            <a href="<?php echo e(route('excel.export')); ?>" class="btn btn-success">Export Excel</a>
                        </div>
                        <div class="mr-4">
                            <form action="<?php echo e(route('applications.deleteAll')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-danger" >
                                    Удалить все <span class="ml-3"></span>
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>

                        </div>
                    </div>

                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Имя</th>
                                <th>Телефон</th>
                                <th>Регион</th>
                                <th>Дата</th>
                                <th>Удалить</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($application->id); ?></td>
                                    <td><?php echo e($application->name); ?></td>
                                    <td><?php echo e($application->phone); ?></td>
                                    <td><?php echo e($application->region); ?></td>
                                    <td><?php echo e($application->created_at->format('d.m.Y H:i:s')); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('applications.destroy', $application)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <input type="hidden" value="<?php echo e($application->id); ?>">
                                            <button class="btn btn-danger" >
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <a href="<?php echo e(route('applications',  ['size'=>25])); ?>"> 25</a> /  <a href="<?php echo e(route('applications',  ['size'=>50])); ?>"> 50</a> /   <a href="<?php echo e(route('applications',  ['size'=>100])); ?>"> 100</a> /   <a href="<?php echo e(route('applications',  ['size'=>200])); ?>"> 200</a>


                    </div>
                </div>

            </div>
            <?php echo e($applications->links()); ?>


    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('scripts'); ?>
    <?php $__env->stopSection(); ?>



 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /home/vagrant/code/mewo/resources/views/admin/zayavki.blade.php ENDPATH**/ ?>