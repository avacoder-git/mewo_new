<!-- Nav Item - Charts -->
<li class="nav-item <?php if(session()->has(['activeness']) && session('activeness')== 'applications'): ?> active   <?php endif; ?>">
    <a class="nav-link " href="<?php echo e(route('applications', ['size'=>25])); ?>">
        <i class="fas fa-fw fa-table"></i>
        <span>Заявки</span></a>
</li>
<?php /**PATH /home/vagrant/code/mewo/resources/views/components/sidebar-zayavki.blade.php ENDPATH**/ ?>