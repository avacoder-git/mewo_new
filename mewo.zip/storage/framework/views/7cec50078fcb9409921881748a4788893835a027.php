<!-- Nav Item - Charts -->
<li class="nav-item <?php if(session()->has(['activeness']) && session('activeness')== 'deseases'): ?> active   <?php endif; ?>">
    <a class="nav-link " href="<?php echo e(route('deseases', ['size'=>25])); ?>">
        <i class="fas fa-fw fa-table"></i>
        <span>Болезни</span></a>
</li>
<?php /**PATH C:\laravel\mewo\resources\views/components/deseases-links.blade.php ENDPATH**/ ?>