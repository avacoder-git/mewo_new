 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin-master','data' => []]); ?>
<?php $component->withName('admin-master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startSection('content'); ?>

        <h1 class="h3 mb-2 text-gray-800">Видео</h1>
        <!-- DataTales Example -->


        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <div class="row">
                    <div class="col-12">
                        <h6 class="m-0 font-weight-bold text-primary">Видео</h6>
                    </div>
                    <div class="ml-auto mr-4">
                        <a class="btn btn-lg btn-primary btn-icon-split" href="<?php echo e(route('videos.create')); ?>">
                                <span class="icon text-white-50">
                                            <i class="fas fa-plus"></i>
                                        </span>
                            <span class="text">Новый</span>
                        </a>
                    </div>
                </div>

            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>Id</th>
                            <th>Обложка</th>
                            <th>Линк</th>
                            <th>Дата</th>
                            <th>Изменить</th>
                            <th>Удалить</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($video->id); ?></td>
                                <td><img height="100px" src="<?php echo e($video->image); ?>" alt=""></td>
                                <td><a href="<?php echo e($video->getlink()); ?>}}"><?php echo e($video->getlink()); ?></a></td>
                                <td><?php echo e($video->created_at->format('d.m.Y')); ?></td>
                                <td><a href="<?php echo e(route('videos.edit', $video)); ?>" class="btn btn-success">Изменить</a></td>
                                <td>
                                    <form action="<?php echo e(route('videos.destroy', $video)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <input type="hidden" value="<?php echo e($video->id); ?>">
                                        <button class="btn btn-danger" >
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <a href="<?php echo e(route('video_comments',  ['size'=>25])); ?>"> 25</a> /  <a href="<?php echo e(route('video_comments',  ['size'=>50])); ?>"> 50</a> /   <a href="<?php echo e(route('video_comments',  ['size'=>100])); ?>"> 100</a> /   <a href="<?php echo e(route('video_comments',  ['size'=>200])); ?>"> 200</a>


                </div>
            </div>

        </div>
        <?php echo e($videos->links()); ?>


    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('scripts'); ?>
    <?php $__env->stopSection(); ?>



 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\laravel\mewo\resources\views/admin/videos/index.blade.php ENDPATH**/ ?>