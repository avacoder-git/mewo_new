<!-- Nav Item - Charts -->
<li class="nav-item <?php if(session()->has(['activeness']) && session('activeness')== 'videos'): ?> active   <?php endif; ?>">
    <a class="nav-link " href="<?php echo e(route('videos', ['size'=>25])); ?>">
        <i class="fas fa-fw fa-table"></i>
        <span>Видео</span></a>
</li>
<?php /**PATH C:\laravel\mewo\resources\views/components/videos-link.blade.php ENDPATH**/ ?>