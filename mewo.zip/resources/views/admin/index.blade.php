<x-admin-master>

    @section('content')




    @endsection



</x-admin-master>
